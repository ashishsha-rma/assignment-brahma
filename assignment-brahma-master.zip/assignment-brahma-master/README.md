![diagram](https://github.com/ashishsharm-a/assignment-brahma/assets/32600576/0f3c16e5-4c91-4286-8152-84f1a712bfca)
